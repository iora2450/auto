<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gire extends Model
{
    //
    protected $fillable =[
        "code", "name", "created_at", "updated_at"
    ];
}
