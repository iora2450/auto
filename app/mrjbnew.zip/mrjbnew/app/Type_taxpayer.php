<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class type_taxpayer extends Model
{
    //
}
