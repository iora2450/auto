<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class type_taxpayer extends Controller
{
    //
}
