<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class QuedanxSale extends Controller
{
    //
}
